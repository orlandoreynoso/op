<div class="cuadro-menu">
  <div class="op-slogan">
    <h2>Provincia San Vicente Ferrer</h2>
    <h3>Dominicos en Centro America</h3>
  </div>
  <div class="movilmenuop">
    <?php logo_provincia(); ?>
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <?php showMenuboostrap(); ?>
  </div>
</div>
</div>
