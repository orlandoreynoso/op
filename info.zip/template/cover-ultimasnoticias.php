<div class="titulo-anuncios">
  <h3>ÚLTIMAS NOTICIAS</h3>
</div>
<article class="listado">
  <?php op_entradas_frontpage();  ?>
</article>
