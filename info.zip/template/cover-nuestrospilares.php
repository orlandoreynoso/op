<div class="titulo-anuncios">
	<h3>Nuestros Pilares</h3>
</div>
<article class="contenidoframe">
  <?php dynamic_sidebar('texto-pilares'); ?>
</article>
<article class="c-info" id="iglesia">

<?php get_template_part( 'template/cover','pilares'); ?>

<?php /*
	<div id="div1" class="ig-p">
		<a class="pilares-ingreso" href="<?php bloginfo('url'); ?>/category/tres-consejos/">
			<img src="<?php echo IMAGES.'/n_estudio.jpg'; ?>" alt="">
			<span>Parroquia - Tres consejos</span>
		</a>
	</div>
	<div id="div1" class="ig-p">
		<a class="pilares-ingreso" href="<?php bloginfo('url'); ?>/molino-de-las-flores/">
			<img src="<?php echo IMAGES.'/n_oracion.jpg'; ?>" alt="">
			<span>Santuario NSSC</span>
		</a>
	</div>
	<div id="div1" class="ig-p">
		<a class="pilares-ingreso" href="<?php bloginfo('url'); ?>/sede-parroquial-el-tesoro/">
			<img src="<?php echo IMAGES.'/n_comunidad.jpg'; ?>" alt="">
			<span>Sede Parroquial El Tesoro</span>
		</a>
	</div>
	<div id="div1" class="ig-p">
		<a class="pilares-ingreso" href="<?php bloginfo('url'); ?>/rectoria-de-santa-rita/">
			<img src="<?php echo IMAGES.'/n_predicacion.jpg'; ?>" alt="">
			<span>Rectoria de Santa Rita</span>
		</a>
	</div>
	*/ ?>
</article>
