<div class="op">
    <?php $logoop = IMAGES.'/orden-de-predicadores.png'; ?>
    <a class="logo" href="http://www.op.org/es"><img src="<?php echo $logoop; ?>" alt="Orden de Predicadores"></a>
  <div class="ingreso">
    <p class="texto">Orden de Predicadores</p>
    <a class="btn-ingresar"href="http://www.op.org/es" target="_blank">
      <span>ingresar</span>
    </a>
  </div>
</div>
<div class="veritas">
  <div class="v_ingreso">
    <p class="texto">Casa de espiritualidad</p>
    <a class="btn-ingresar"href="http://casaveritas.org/" target="_blank">
      <span>ingresar</span>
    </a>
  </div>
  <?php $logoveritas = IMAGES.'/casa-veritas-logo.png'; ?>
  <a class="v_logo" href="http://casaveritas.org/"><img src="<?php echo $logoveritas; ?>" alt="Casa Veritas"></a>
</div>
