<div class="img-provincial">
  <div class="container-fluid">
  <div class="row">
    <!-- div class="col-sm-12 col-md-4 imgpresencia">
      <?php // get_template_part( 'template/cover','presenciaportada'); ?>
    </div -->
    <div class="col-sm-12 col-md-12 contenidopresencia">
      <?php get_template_part( 'template/cover','presencials'); ?>
    </div>
  </div>
</div>
</div>
