<div class="titulo-presencia">
	<h3>Dónde estamos en Centroamérica</h3>
</div>
<div class="lugares">
  <?php  $id_presencia = 57; ?>
  <?php /* inc/contenidos/ */ ?>
  <?php presencia($id_presencia);    ?>
</div>
