
    <div class="row">
      <div class="col-md-12">
        <div>
        	<?php //echo do_shortcode("[metaslider id=4323]");  ?>
        	<?php  echo do_shortcode("[metaslider id=15]");  ?>
        </div>
      </div>
    </div>
