<!-- div class="titulo-fraile">
	<h3>Vocacional</h3>
</div -->
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<div class="cuadro">
				<P class="texto">Noticias de la Provincia de San Vicente Ferrer</P>
				<?php
				$widgetNL = new WYSIJA_NL_Widget(true);
				echo $widgetNL->widget(array('form' => 1, 'form_type' => 'php'));
				//   dynamic_sidebar('suscripcion');        ?>
				</div>
			</div>
		</div>
	</div>
