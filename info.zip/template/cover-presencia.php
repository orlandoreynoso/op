<div class="img-provincial">
  <div class="container-fluid">
  <div class="row">
    <div class="col-sm-12 col-md-4 imgpresencia">
      <?php get_template_part( 'template/cover','presenciaportada'); ?>
    </div>
    <div class="col-sm-12 col-md-8 contenidopresencia">
      <?php get_template_part( 'template/cover','presencialistado'); ?>
    </div>
  </div>
</div>
</div>
