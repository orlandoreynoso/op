<div class="contenido-espiritualidad">
  <div class="container">
    <div class="row">
      <div class="titulo-espiritualidad">
        <h3>Espiritualidad</h3>
      </div>
    <?php //get_template_part( 'template/cover', 'homilias');  ?>
    <?php get_template_part( 'template/cover', 'homirefle');  ?>
    <?php// get_template_part( 'template/cover', 'reflexiones');  ?>

    <?php /*
    <div class="c-e">
    <a href="<?php bloginfo('url'); ?>/molino-de-las-flores/">
    <img src="<?php echo IMAGES.'/santuario.jpg'; ?>" alt="">
    <span>Santuario NSSC</span>
    </a>
    </div>
    */ ?>
    </div>
  </div>
</div>
